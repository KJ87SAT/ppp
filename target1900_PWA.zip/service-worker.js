const CACHE_NAME = "target1900-cache-v1";
const ASSETS = [
  "./index.html",
  "./part1.html",
  "./part2.html",
  "./part3.html",
  "./part4.html",
  "./fonts.css",
  "./chart.umd.min.js",
  "./zen-400.woff2",
  "./zen-500.woff2",
  "./zen-700.woff2",
  "./zen-900.woff2",
  "./spectral-400.woff2",
  "./spectral-500italic.woff2",
  "./spectral-600.woff2",
  "./spectral-700.woff2",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-512-maskable.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Only handle same-origin GET requests; let the dictionary API pass through to the network.
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return response;
        })
        .catch(() => cached);
    })
  );
});
